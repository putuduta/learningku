<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Materials - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Materials - Learningku']); ?>
    <style>
        .fa-stack.small { font-size: 0.5em; }
        i { vertical-align: middle; }
    </style>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <section id="headerClassSubject">
        <div id="content" class="container pt-5 mt-5">
            <section id="headerClassDetail">
    
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-10">
                                <h2 class="fw-bold">Subject <?php echo e($classSubject->name); ?></h2>
                                <h5 class="pb-2">Teacher: <?php echo e($classSubject->teacherName); ?> - <?php echo e($classSubject->teacherNuptk); ?></h5>
                                <h5><span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-home fa-stack-1x fa-2xs fa-inverse text-white"></i></span> <?php echo e($classSubject->className); ?> - <?php echo e($classSubject->schoolYear); ?> <?php echo e($classSubject->semester); ?> <span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-user fa-stack-1x fa-2xs fa-inverse text-white"></i></span> Homeroom Teacher: <?php echo e($classSubject->homeRoomTeacherName); ?> - <?php echo e($classSubject->homeRoomTeacherNuptk); ?></h5>
                            </div>           
                        </div>
                    </div>
                </div>
            </section>

            <nav class="" style="font-size:1.25rem">
                
                    <ul class="nav nav-tabs">
                        <?php if(auth()->user()->role->name == 'Teacher'): ?>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('class-view-student', $classSubject->id )); ?>">Students</a></li>
                        <?php endif; ?>
        
                        <?php if(auth()->user()->role->name == 'Student'): ?>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                        <?php endif; ?>
                    </ul>
                
            </nav>
        </div>
    </section>

    <div id="content" class="container my-3">
        
        <?php if(auth()->user()->role->name == 'Teacher'): ?>
            <div class="text-end">
                <button type="button" class="btn btn-primary text-white mb-3" data-bs-toggle="modal"
                    data-bs-target="#newMaterial">
                    Create New Material
                </button>
            </div>
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-2" style="width: 100%">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($material->title); ?></h5>
                    <p class="card-text"><?php echo $material->description; ?></p>
                    <div class="left d-flex justify-content-between">
                        <div>
                            <?php if($material->resource != null || $material->resource != ""): ?>                       
                                <a class="btn btn-success text-white" href="<?php echo e(route('material.download', $material->id)); ?>" target="_blank">Download File</a>
                            <?php endif; ?>
                        </div>
                        <div class="d-flex">
                            <div class="me-2">
                                <button type="button" class="btn btn-primary text-white justify-content-between" data-bs-toggle="modal"
                                data-bs-target="#updateMaterial<?php echo e($material->id); ?>">
                                    Update
                                </button>
                            </div>
                            <div>
                                <form action="<?php echo e(route('material.delete', $material->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger text-white" onclick="return confirm('Are you sure?')">
                                        Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(auth()->user()->role->name == 'Student'): ?>
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-2" style="width: 100%">
                <div class="card-body">
                    <h2 class="card-title pb-3"><?php echo e($material->title); ?></h2>
                    <?php echo $material->description; ?>

                    <?php if($material->resource != null || $material->resource != ""): ?> 
                        <div class="pt-3"><a class="btn btn-primary text-white" href="<?php echo e($material->resource); ?>">Download File</a></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="modal fade" id="newMaterial" tabindex="-1" aria-labelledby="newMaterialLabel"
    aria-hidden="true" data-bs-focus="false">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="submitLabel">Create New Material</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('material.create')); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="my-3">
                        <label for="class_subject_id" class="form-label" hidden>Class Id</label>
                        <input value="<?php echo e($classSubject->id); ?>" type="text" class="form-control" name="class_subject_id" id="class_subject_id" readonly required hidden>
                    </div>
                    <div class="my-3">
                        <label for="title" class="form-label">Title <span class="required">*</span></label>
                        <input type="text" class="form-control" name="title" id="title" required>
                    </div>
                    <div class="my-3">
                        <label for="description" class="form-label">Description <span class="required">*</span></label>
                        <textarea id="createDescription" name="description" id="description" cols="30" rows="10" class="form-control"></textarea>
                    </div>
                    <div class="my-3">
                        <label for="resource" class="form-label">Resource</label>
                        <input type="file" class="form-control" name="file" id="file">
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="updateMaterial<?php echo e($material->id); ?>" tabindex="-1" aria-labelledby="updateMaterial"
        aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="submitLabel">Update Material</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('material.update', $material->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="my-3">
                            <label for="class_subject_id" class="form-label" hidden>Class Id</label>
                            <input value="<?php echo e($classSubject->id); ?>" type="text" class="form-control" name="class_subject_id" id="class_subject_id" readonly required hidden>
                        </div>
                        <div class="my-3">
                            <label for="title" class="form-label">Title <span class="required">*</span></label>
                            <input type="text" value="<?php echo e($material->title); ?>" class="form-control" name="title" id="title" required>
                        </div>
                        <div class="my-3">
                            <label for="description" class="form-label">Description <span class="required">*</span></label>
                            <textarea id="updateDescription-<?php echo e($material->id); ?>" name="description" value="<?php echo e($material->description); ?>" cols="30" rows="10" class="form-control"><?php echo e($material->description); ?></textarea>
                        </div>
                        <div class="my-3">
                            <label for="resource" class="form-label">Resource</label>
                            <input type="file" class="form-control" name="file" id="file">
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    ClassicEditor
        .create( document.querySelector( '#createDescription' ) )
        .catch( error => {
            console.error( error );
        } );

    var materials = <?php echo json_encode($materials->toArray()); ?>;
    materials.forEach(function(item) {
        ClassicEditor
            .create(document.querySelector('#updateDescription-' + item.id))
            .catch(error => {
                console.error(error);
        });
    });

    $('.modal').modal( {
        focus: false
    });
    
</script>
<?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/material/index.blade.php ENDPATH**/ ?>