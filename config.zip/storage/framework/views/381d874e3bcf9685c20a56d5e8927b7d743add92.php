<?php if(auth()->user()->role->name == 'Student'): ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Attendances - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Attendances - Learningku']); ?>
    <style>
        .fa-stack.small { font-size: 0.5em; }
        i { vertical-align: middle; }
    </style>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <section id="headerClassSubject">
        <div id="content" class="container pt-5 mt-5">
            <section id="headerClassDetail">
    
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-10">
                                <h2 class="fw-bold">Subject <?php echo e($classSubject->name); ?></h2>
                                <h5 class="pb-2">Teacher: <?php echo e($classSubject->teacherName); ?> - <?php echo e($classSubject->teacherNuptk); ?></h5>
                                <h5><span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-home fa-stack-1x fa-2xs fa-inverse text-white"></i></span> <?php echo e($classSubject->className); ?> - <?php echo e($classSubject->schoolYear); ?> <?php echo e($classSubject->semester); ?> <span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-user fa-stack-1x fa-2xs fa-inverse text-white"></i></span> Homeroom Teacher: <?php echo e($classSubject->homeRoomTeacherName); ?> - <?php echo e($classSubject->homeRoomTeacherNuptk); ?></h5>
                            </div>           
                        </div>
                    </div>
                </div>
            </section>
    
    
            <nav class="" style="font-size:1.25rem">
                
                    <ul class="nav nav-tabs">
                        <?php if(auth()->user()->role->name == 'Teacher'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('class-view-student', $classSubject->id )); ?>">Students</a></li>
                        <?php endif; ?>
        
                        <?php if(auth()->user()->role->name == 'Student'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                        <?php endif; ?>
                    </ul>
                
            </nav>
        </div>
    </section>

    <div id="content" class="container my-3">
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">Total Present</th>
                    <th class="align-middle text-center">Total Sick</th>
                    <th class="align-middle text-center">Total Absence Permit</th>
                    <th class="align-middle text-center">Total Absent</th>
                </thead>
                <tbody>
                    <td class="align-middle text-center">
                        <?php echo e(count($attendances->where("status", "Present"))); ?></td>
                    <td class="align-middle text-center">
                        <?php echo e(count($attendances->where("status", "Sick"))); ?></td></td>
                    <td class="align-middle text-center">
                        <?php echo e(count($attendances->where("status", "Absence Permit"))); ?></td></td>
                    <td class="align-middle text-center">
                        <?php echo e(count($attendances->where("status", "Absent"))); ?></td></td>                            
                </tbody>
            </table>
        </div>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">No</th>
                    <th class="align-middle text-center">Date</th>
                    <th class="align-middle text-center">Status</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle text-center"><?php echo e($index+1); ?></td>
                        <td class="align-middle text-center">
                            <?php echo e(date_format(date_create($attendance->header->date),"d F Y")); ?>

                        </td>
                        <?php if($attendance->status == 'Present'): ?>
                        <td class="align-middle text-center bg-success text-white">
                            Present
                        </td>
                        <?php elseif($attendance->status == 'Sick'): ?>
                        <td class="align-middle text-center text-white" style="background-color: orange;">
                            Sick
                        </td>  
                        <?php elseif($attendance->status == 'Absence Permit'): ?>
                        <td class="align-middle text-center text-white" style="background-color: orange;">
                            Absence Permit
                        </td>
                        <?php else: ?> 
                        <td class="align-middle text-center bg-danger text-white">
                            Absent
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php else: ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Attendances - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Attendances - Learningku']); ?>
    <style>
        .fa-stack.small { font-size: 0.5em; }
        i { vertical-align: middle; }
    </style>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <section id="headerClassSubject">
        <div id="content" class="container pt-5 mt-5">
            <section id="headerClassDetail">
    
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-10">
                                <h2 class="fw-bold">Subject <?php echo e($classSubject->name); ?></h2>
                                <h5 class="pb-2">Teacher: <?php echo e($classSubject->teacherName); ?> - <?php echo e($classSubject->teacherNuptk); ?></h5>
                                <h5><span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-home fa-stack-1x fa-2xs fa-inverse text-white"></i></span> <?php echo e($classSubject->className); ?> - <?php echo e($classSubject->schoolYear); ?> <?php echo e($classSubject->semester); ?> <span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-user fa-stack-1x fa-2xs fa-inverse text-white"></i></span> Homeroom Teacher: <?php echo e($classSubject->homeRoomTeacherName); ?> - <?php echo e($classSubject->homeRoomTeacherNuptk); ?></h5>
                            </div>           
                        </div>
                    </div>
                </div>
            </section>
    
            <nav class="" style="font-size:1.25rem">
                
                    <ul class="nav nav-tabs">
                        <?php if(auth()->user()->role->name == 'Teacher'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('class-view-student', $classSubject->id )); ?>">Students</a></li>
                        <?php endif; ?>
        
                        <?php if(auth()->user()->role->name == 'Student'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                        <?php endif; ?>
                    </ul>
                
            </nav>
        </div>
    </section>



    <div id="content" class="container my-3">
        <div class="text-end">
            <a href="<?php echo e(route('attendance.view-create',$classSubject->id)); ?>" class="btn btn-primary text-white mb-3">Do Student
                Attendance</a>
        </div>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">No</th>
                    <th class="align-middle text-center">Date</th>
                    <th class="align-middle text-center">Class</th>
                    <th class="align-middle text-center">Subject</th>
                    <th class="align-middle text-center">Actions</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle text-center"><?php echo e($index+1); ?></td>
                        <td class="align-middle text-center"><?php echo e(date_format(date_create($attendance->date),"d F Y")); ?>

                        </td>
                        <td class="align-middle text-center"><?php echo e($attendance->className); ?></td>
                        <td class="align-middle text-center"><?php echo e($attendance->subjectName); ?></td>
                        <td class="align-middle text-center">
                            <button type="button" class="btn btn-primary text-white" data-bs-toggle="modal"
                                data-bs-target="#detail-<?php echo e($attendance->id); ?>">
                                Details
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="detail-<?php echo e($attendance->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Attendance Detail - <?php echo e($attendance->id); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h5>Date: <?php echo e(date_format(date_create($attendance->date),"d F Y")); ?></h5>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead class="table-dark">
                            <th class="align-middle text-center">Total Present</th>
                            <th class="align-middle text-center">Total Sick</th>
                            <th class="align-middle text-center">Total Absence Permit</th>
                            <th class="align-middle text-center">Total Absent</th>
                        </thead>
                        <tbody>
                            <td class="align-middle text-center">
                                <?php echo e(count($attendance->details->where("status", "Present"))); ?></td>
                            <td class="align-middle text-center">
                                <?php echo e(count($attendance->details->where("status", "Sick"))); ?></td></td>
                            <td class="align-middle text-center">
                                <?php echo e(count($attendance->details->where("status", "Absence Permit"))); ?></td></td>
                            <td class="align-middle text-center">
                                <?php echo e(count($attendance->details->where("status", "Absent"))); ?></td></td>                            
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead class="table-dark">
                            <th class="align-middle text-center">No</th>
                            <th class="align-middle text-center">NISN</th>
                            <th class="align-middle text-center">Student Name</th>
                            <th class="align-middle text-center">Status</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $attendance->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($student->studentId == $detail->student->id): ?>
                            <tr>
                                <td class="align-middle text-center">
                                    <?php echo e($index+1); ?></td>
                                <td class="align-middle text-center">
                                        <?php echo e($student->studentNisn); ?></td>
                                <td class="align-middle text-center">
                                    <?php echo e($detail->student->name); ?></td>

                                    <?php if($detail->status == 'Present'): ?>
                                    <td class="align-middle text-center bg-success text-white">
                                        Present
                                    </td>
                                    <?php elseif($detail->status == 'Sick'): ?>
                                    <td class="align-middle text-center text-white" style="background-color: orange;">
                                        Sick
                                    </td>  
                                    <?php elseif($detail->status == 'Absence Permit'): ?>
                                    <td class="align-middle text-center text-white" style="background-color: orange;">
                                        Absence Permit
                                    </td>
                                    <?php else: ?> 
                                    <td class="align-middle text-center bg-danger text-white">
                                        Absent
                                    </td>
                                    <?php endif; ?>
                            </tr>                                
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary text-white" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/attendance/index.blade.php ENDPATH**/ ?>