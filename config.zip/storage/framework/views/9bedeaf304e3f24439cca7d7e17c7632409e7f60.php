<header class="navbar-top">
    <nav class="navbar navbar-expand-lg fixed-top shadow-sm bg-dark">
        <div class="d-inline-flex">
            <span class="color-teal mx-3" id="show-sidebar" style="cursor: pointer;">
                <h2 class="text-white">☰</h2>
            </span>
            <a class="navbar-brand" href="/dashboard">
                <h2 class="text-white">LEARNINGKU</h2>
            </a>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/components/navbar-user.blade.php ENDPATH**/ ?>