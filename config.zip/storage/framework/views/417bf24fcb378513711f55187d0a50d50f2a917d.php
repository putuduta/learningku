<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Student List']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Student List']); ?>
      <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

     <div id="content" class="container py-5 my-5">
          <h3 class="fw-bold">Student List</h3>
          <button type="button" class="btn btn-primary text-white mb-3" data-bs-toggle="modal"
               data-bs-target="#newStudent">
               Add New Student
          </button>
          <div class="table-responsive">
               <table class="table table-hover table-bordered">
                   <thead class="table-light">
                         <th class="align-middle text-center">No</th>
                         <th class="align-middle text-center">Student Name</th>
                         <th class="align-middle text-center">NISN</th>
                         <th class="align-middle text-center">Action</th>
                    </thead>
                    <tbody>
                         <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                   <td class="align-middle text-center"><?php echo e($index+1); ?></td>
                                   <td class="align-middle text-center"><?php echo e($student->name); ?></td>
                                   <td class="align-middle text-center"><?php echo e($student->nisn); ?></td>
                                   <td class="align-middle text-center">
                                        <button type="button" class="btn btn-primary text-white justify-content-between" data-bs-toggle="modal"
                                        data-bs-target="#updateStudent<?php echo e($student->id); ?>">
                                            Update
                                        </button>

                                        <button type="button" class="btn btn-danger text-white justify-content-between"
                                             data-bs-toggle="modal"
                                             data-bs-target="#delete-<?php echo e($student->id); ?>">
                                             Remove
                                        </button>
                                        
                                   </td>
                              </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
               </table>
          </div>
     </div>

     <div class="modal fade" id="newStudent" tabindex="-1" aria-labelledby="newStudentLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
          <div class="modal-content">
               <div class="modal-header">
                    <h5 class="modal-title" id="submitLabel">Add New Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
               </div>
               <div class="modal-body">
                    <form action="<?php echo e(route('student-add')); ?>" method="POST" enctype="multipart/form-data">
                         <?php echo csrf_field(); ?>
                         <div class="my-3">
                              <label for="name" class="form-label">Student Name <span class="required">*</span></label>
                              <input type="text" class="form-control" name="name" required>
                         </div>
                         <div class="my-3">
                              <label for="nisn" class="form-label">NISN <span class="required">*</span></label>
                              <input type="text" class="form-control" name="nisn" maxlength="10" required>
                         </div>
                         <div class="my-3">
                              <label for="email" class="form-label">Email <span class="required">*</span></label>
                              <input type="email" class="form-control" name="email" required>
                         </div>
                         <div class="my-3">
                              <label for="gender" class="form-label">Gender <span class="required">*</span></label>
                              <div>
                                   <div class="form-check-inline">
                                        <label class="form-check-label">
                                          <input type="radio" class="form-check-input" value="Male" name="gender" required> Male
                                        </label>
                                      </div>
                                      <div class="form-check-inline">
                                        <label class="form-check-label">
                                          <input type="radio" class="form-check-input" value="Female"  name="gender" required> Female
                                        </label>
                                   </div>
                              </div>
                         </div>
                         <div class="my-3">
                              <label for="image" class="form-label">Student Image</label>
                              <input type="file" class="form-control" name="image">
                         </div>
                         <div class="d-grid">
                              <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                          </div>
                    </form>
               </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="updateStudent<?php echo e($student->id); ?>" tabindex="-1" aria-labelledby="updateStudent"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="submitLabel">Update Student</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('student-update', $student->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="my-3">
                                 <label for="name" class="form-label">Student Name <span class="required">*</span></label>
                                 <input type="text" class="form-control" name="name" value="<?php echo e($student->name); ?>" required>
                            </div>
                            <div class="my-3">
                                 <label for="nisn" class="form-label">NISN <span class="required">*</span></label>
                                 <input type="text" class="form-control" name="nisn" value="<?php echo e($student->nisn); ?>" required>
                            </div>
                            <div class="my-3">
                                 <label for="email" class="form-label">Email <span class="required">*</span></label>
                                 <input type="email" class="form-control" name="email" value="<?php echo e($student->email); ?>" required>
                            </div>
                            <div class="my-3">
                                 <label for="password" class="form-label">Password <span class="required">*</span></label>
                                 <input type="password" class="form-control" name="password" value="<?php echo e($student->password); ?>" required>
                            </div>
                            <div class="my-3">
                              <label for="gender" class="form-label">Gender <span class="required">*</span></label>
                                   <div>
                                        <div class="form-check-inline">
                                             <label class="form-check-label">
                                             <input type="radio" class="form-check-input" name="gender" value="Male" <?php if($student->gender == "Male"): ?>
                                                checked 
                                             <?php endif; ?> required> Male
                                             </label>
                                        </div>
                                        <div class="form-check-inline">
                                             <label class="form-check-label">
                                             <input type="radio" class="form-check-input" name="gender" value="Female" <?php if($student->gender == "Female"): ?>
                                                  checked 
                                             <?php endif; ?>> Female
                                             </label>
                                        </div>
                                   </div>
                            </div>
                            <div class="my-3">
                              <label for="image" class="form-label">Student Image</label>
                              <input type="file" class="form-control" name="image">
                            </div>
                            <div class="d-grid">
                              <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                          </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade show pr-0" style="z-index: 9999;" id="delete-<?php echo e($student->id); ?>"
        tabindex="-1" role="dialog" aria-labelledby="alertTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content rounded-20 border-0">
                <div class="modal-header border-bottom-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row d-flex justify-content-center align-items-center">
                        <div class="col-12 mb-3 text-center">
                            <span class="fa-stack fa-4x">
                                <i class="fas fa-circle fa-stack-2x text-danger"></i>
                                <i class="fas fa-exclamation-triangle fa-stack-1x fa-inverse"></i>
                            </span>
                        </div>
                        <div class="col-12 my-2 text-center">
                            <h4 class="font-weight-bold">Are you sure want to remove this data?</h4>

                            <div class="d-flex justify-content-center">
                                <button type="button" class="btn btn-light text-dark justify-content-between mx-2"
                                    data-bs-dismiss="modal">
                                    Cancel
                                </button>
                                <form action="<?php echo e(route('student-remove', $student->id)); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger text-white justify-content-between">
                                        Yes, remove it
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


<?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/admin/student-list.blade.php ENDPATH**/ ?>