<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Class List - '.e($schoolYear->year).' '.e($schoolYear->semester).'']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Class List - '.e($schoolYear->year).' '.e($schoolYear->semester).'']); ?>
      <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

     <div id="content" class="container py-5 my-5">
          <h3 class="fw-bold">Class List - Tahun Ajaran <?php echo e($schoolYear->year); ?> - <?php echo e($schoolYear->semester); ?></h3>

          <a type="button" class="btn btn-dark text-white mb-3" href="<?php echo e(url()->previous()); ?>">
          Back
          </a>
          <button type="button" class="btn btn-primary text-white mb-3" data-bs-toggle="modal"
          data-bs-target="#newClass">
          Add Class
          </button>
          <div class="table-responsive">
               <table class="table table-hover table-bordered">
                   <thead class="table-light">
                         <th class="align-middle text-center">No</th>
                         <th class="align-middle text-center">Class Name</th>
                         <th class="align-middle text-center">Homeroom Teacher/Wali Kelas</th>
                         <th class="align-middle text-center" colspan="4">Action</th>
                    </thead>
                    <tbody>
                         <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                   <td class="align-middle text-center"><?php echo e($index+1); ?></td>
                                   <td class="align-middle text-center"><?php echo e($class->name); ?></td>
                                   <td class="align-middle text-center"><?php echo e($class->homeroomTeacherName); ?></td>
                                   <td class="align-middle text-center">
                                        <button type="button" class="btn btn-primary text-white justify-content-between" data-bs-toggle="modal"
                                        data-bs-target="#updateClass<?php echo e($class->id); ?>">
                                             Edit
                                        </button>
                                        <a href="<?php echo e(route('admin-class-view-subject',$class)); ?>"
                                        class="btn btn-success text-white">Subject and Teacher List</a>
                                        <a href="<?php echo e(route('admin-class-view-student',$class->id)); ?>"
                                             class="btn btn-secondary text-white">Students</a>

                                        <button type="button" class="btn btn-danger text-white justify-content-between"
                                             data-bs-toggle="modal"
                                             data-bs-target="#delete-<?php echo e($class->id); ?>">
                                             Remove
                                        </button>
                                   </td>
                              </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
               </table>
          </div>

          <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="modal fade show pr-0" style="z-index: 9999;" id="delete-<?php echo e($class->id); ?>"
               tabindex="-1" role="dialog" aria-labelledby="alertTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                         <div class="modal-content rounded-20 border-0">
                              <div class="modal-header border-bottom-0">
                                   <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                   <div class="row d-flex justify-content-center align-items-center">
                                        <div class="col-12 mb-3 text-center">
                                        <span class="fa-stack fa-4x">
                                             <i class="fas fa-circle fa-stack-2x text-danger"></i>
                                             <i class="fas fa-exclamation-triangle fa-stack-1x fa-inverse"></i>
                                        </span>
                                        </div>
                                        <div class="col-12 my-2 text-center">
                                        <h4 class="font-weight-bold">Are you sure want to remove this data?</h4>

                                        <div class="d-flex justify-content-center">
                                             <button type="button" class="btn btn-light text-dark justify-content-between mx-2"
                                                  data-bs-dismiss="modal">
                                                  Cancel
                                             </button>
                                             <form action="<?php echo e(route('admin-class-remove', $class->id)); ?>"
                                                  method="POST">
                                                  <?php echo csrf_field(); ?>
                                                  <?php echo method_field('delete'); ?>
                                                  <button type="submit" class="btn btn-danger text-white justify-content-between">
                                                       Yes, remove it
                                                  </button>
                                             </form>
                                        </div>
                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="modal fade" id="newClass" tabindex="-1" aria-labelledby="newClass"
          aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered modal-lg">
                   <div class="modal-content">
                       <div class="modal-header">
                           <h5 class="modal-title" id="submitLabel">Add Class</h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                       </div>
                       <div class="modal-body">
                         <form method="POST" action="<?php echo e(route('admin-class-create', $schoolYear->id)); ?>">
                              <?php echo csrf_field(); ?>
                              <div class="">
                                   <label for="school_year" class="form-label">School Year</label>
                                   <input type="text" class="form-control" name="school_year" value="<?php echo e($schoolYear->year); ?> - <?php echo e($schoolYear->semester); ?>" readonly>
                              </div>
                              <div class="my-3">
                                   <label for="class_name" class="form-label">Class Name <span class="required">*</span></label>
                                   <input type="text" class="form-control" name="class_name" required>
                              </div>
                              <div class="my-3">
                                   <label for="homeroom_teacher_id" class="form-label">Homeroom Teacher <span class="required">*</span></label>
                                   <select name="homeroom_teacher_id" class="form-select" required>
                                        <option value="" selected>--Please Choose--</option>
                                        <?php $__currentLoopData = $teachersNotAssigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->teacherNuptk); ?> - <?php echo e($teacher->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select>
                              </div>
                              <div class="d-grid">
                                   <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                               </div>
                         </form>
                       </div>
                   </div>
               </div>
          </div>

          <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="modal fade" id="updateClass<?php echo e($class->id); ?>" tabindex="-1" aria-labelledby="updateSchoolYear"
                  aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-lg">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="submitLabel">Edit Class</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                              <form action="<?php echo e(route('admin-class-update', $class->id)); ?>" method="POST"
                                  enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('put'); ?>
                                  <div class="">
                                       <input type="text" class="form-control" name="school_year_id" value="<?php echo e($schoolYear->id); ?>" hidden>
                                       <label for="school_year" class="form-label">School Year</label>
                                       <input type="text" class="form-control" name="school_year" value="<?php echo e($schoolYear->year); ?> - <?php echo e($schoolYear->semester); ?>" readonly>
                                  </div>
                                  <div class="my-3">
                                       <label for="class_name" class="form-label">Class Name <span class="required">*</span></label>
                                       <input type="text" class="form-control" value="<?php echo e($class->name); ?>" name="class_name" required>
                                  </div>
                                  <div class="my-3">
                                       <label for="homeroom_teacher_id" class="form-label">Homeroom Teacher <span class="required">*</span></label>
                                       <select name="homeroom_teacher_id" class="form-select" required>
                                            <option value="" selected>--Please Choose--</option>
                                            <option value="<?php echo e($class->homeroomTeacherId); ?>" selected><?php echo e($class->teacherNuptk); ?> - <?php echo e($class->homeroomTeacherName); ?></option> 
                            
                                            <?php $__currentLoopData = $teachersNotAssigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($teacher->id); ?>" <?php echo e(($class->homeroom_teacher_id === $teacher->id) ? 'selected' : ''); ?>><?php echo e($teacher->teacherNuptk); ?> - <?php echo e($teacher->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                  </div>
                                  <div class="d-grid">
                                   <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                               </div>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/admin/class-list.blade.php ENDPATH**/ ?>