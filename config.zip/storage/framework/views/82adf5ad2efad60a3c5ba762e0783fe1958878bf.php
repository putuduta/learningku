<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Forum Detail - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Forum Detail - Learningku']); ?>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <div id="content" class="container py-5 my-5">
        <div class="mb-3">
            <span class="fa-stack fa-md ms-n1">
                <i class="fas fa-circle fa-stack-2x text-orange"></i>
                <a href="<?php echo e(route('forum.index', $classSubject->id )); ?>" class="fas fa-arrow-left fa-stack-1x fa-inverse text-light" style="text-decoration: none;"></a>
            </span>
        </div>
        
        <div class="card shadow-sm border-0">
            <div class="card-body my-2">
                <h3 class="fw-bold"><?php echo e($forum->title); ?></h3>
                <p>
                    Subject <?php echo e($classSubject->name); ?>

                    <br>
                    Created at  <?php echo e(date_format(date_create($forum->created_at),"d F Y H:i")); ?></p>
                <hr>
                <h5 class="fw-bold"><?php echo e($forum->user->name); ?> 
                    <br>
                    <span class="smallFont" style="font-weight: normal !important;">
                        <?php if($forum->user->role->name == 'Student'): ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($student->id == $forum->teacher_user_id): ?>
                                NISN: <?php echo e($student->nisn); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($teacher->id == $forum->teacher_user_id): ?>
                                    NUPTK: <?php echo e($teacher->nuptk); ?>

                                <?php endif; ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </span>
                </h5>
     
             
                <p><?php echo $forum->description; ?>

                </p>
                <a href="/storage/forum/<?php echo e($forum->file); ?>" target="_blank" download=""><?php echo e($forum->file); ?></a>
                <div class="d-flex justify-content-start mt-3">
                    <div class="mx-1">
                        <button type="button" class="btn btn-primary text-white" data-bs-toggle="modal"
                            data-bs-target="#createReply">
                            Reply
                        </button>
                    </div>
                    <div class="mx-1">
                        <?php if($forum->teacher_user_id == auth()->user()->id): ?>
                            <button type="button" class="btn btn-info text-white" data-bs-toggle="modal"
                            data-bs-target="#editThread">
                            Edit Forum
                        </button>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="modal fade" id="editThread" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true" data-bs-focus="false">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit Forum Thread</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('forum.update',$forum->id)); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="my-3">
                                        <label for="title" class="form-label">Title <span class="required">*</span></label>
                                        <input type="text" class="form-control" name="title" id="title" required
                                            value="<?php echo e($forum->title); ?>">
                                    </div>
                                    <div class="my-3">
                                        <label for="description" class="form-label">Description <span class="required">*</span></label>
                                        <textarea name="description" id="body" cols="30" rows="10" class="form-control"
                                            ><?php echo e($forum->description); ?></textarea>
                                    </div>
                                    <div class="my-3">
                                        <label for="file" class="form-label">Attached File</label>
                                        <input class="form-control" name="file" type="file" id="file"
                                            value="<?php echo e($forum->file); ?>">
                                    </div>
                                    <div class="d-grid">
                                        <?php echo method_field('put'); ?>
                                        <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <hr>
        <h5 class="fw-bold mt-3 ms-2"><?php echo e(count($forum->replies)); ?> replies</h5>
        <?php $__currentLoopData = $forum->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card shadow-sm border-0 my-3">
            <div class="card-body my-2">
                <h5 class="fw-bold"><?php echo e($reply->user->name); ?>

                    <br>
                    <span class="smallFont" style="font-weight: normal !important;">
                        <?php if($reply->user->role->name == 'Student'): ?>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($student->id == $reply->user_id): ?>
                                    NISN: <?php echo e($student->nisn); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($teacher->id == $reply->user_id): ?>
                                    NUPTK: <?php echo e($teacher->nuptk); ?>

                                <?php endif; ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </span>
                    <br>
                    <span class="smallFont" style="font-weight: normal !important;">Created at  <?php echo e(date_format(date_create($reply->created_at),"d F Y H:i")); ?></p></span>
                </h5>
                <p><?php echo $reply->description; ?>

                </p>

                <?php if($reply->file): ?>
                <a href="/storage/forum/<?php echo e($reply->file); ?>" class="btn btn-secondary text-white" target="_blank"
                    download=""><?php echo e($reply->file); ?></a>
                <?php endif; ?>

                <?php if($reply->user_id == auth()->user()->id): ?>
                <div class="d-flex mt-3 justify-content-start my-1">
                    <div class="mx-1">
                        <button type="button" class="btn btn-info text-white" data-bs-toggle="modal"
                            data-bs-target="#editReply-<?php echo e($reply->id); ?>">
                            Edit Reply
                        </button>
                    </div>

                    <div class="mx-1">
                        <button type="button" class="btn btn-danger text-white"
                            data-bs-toggle="modal"
                            data-bs-target="#delete-<?php echo e($reply->id); ?>">
                            Delete
                        </button>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php $__currentLoopData = $forum->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade show pr-0" style="z-index: 9999;" id="delete-<?php echo e($reply->id); ?>"
        tabindex="-1" role="dialog" aria-labelledby="alertTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content rounded-20 border-0">
                    <div class="modal-header border-bottom-0">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                            <div class="row d-flex justify-content-center align-items-center">
                                <div class="col-12 mb-3 text-center">
                                <span class="fa-stack fa-4x">
                                    <i class="fas fa-circle fa-stack-2x text-danger"></i>
                                    <i class="fas fa-exclamation-triangle fa-stack-1x fa-inverse"></i>
                                </span>
                                </div>
                                <div class="col-12 my-2 text-center">
                                <h4 class="font-weight-bold">Are you sure want to delete this data?</h4>

                                <div class="d-flex justify-content-center">
                                    <button type="button" class="btn btn-light text-dark justify-content-between mx-2"
                                        data-bs-dismiss="modal">
                                        Cancel
                                    </button>
                                    <form action="<?php echo e(route('reply-forum.destroy', $reply->id)); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger text-white justify-content-between">
                                                Yes, delete it
                                        </button>
                                    </form>
                                </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $forum->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="editReply-<?php echo e($reply->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Reply Thread</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('reply-forum.update',$reply->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="my-3">
                            <label for="description" class="form-label">Description <span class="required">*</span></label>
                            <textarea name="description" id="bodyEditReply-<?php echo e($reply->id); ?>" cols="30" rows="10" class="form-control"
                                ><?php echo e($reply->description); ?></textarea>
                        </div>
                        <div class="my-3">
                            <label for="file" class="form-label">Attached File</label>
                            <input class="form-control" name="file" type="file" id="file"
                                value="<?php echo e($reply->file); ?>">
                        </div>
                        <div class="d-grid">
                            <?php echo method_field('put'); ?>
                            <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Modal -->
    <div class="modal fade" id="createReply" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Create Reply Thread</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('reply-forum.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="my-3">
                            <label for="description" class="form-label">Description <span class="required">*</span></label>
                            <textarea name="description" id="bodyForum" cols="30" rows="10" class="form-control"></textarea>
                        </div>
                        <div class="my-3">
                            <label for="file" class="form-label">Attached File</label>
                            <input class="form-control" name="file" type="file" id="file">
                        </div>
                        <input type="hidden" name="forum_id" value="<?php echo e($forum->id); ?>">
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


<script>
    ClassicEditor
        .create( document.querySelector( '#body' ) )
        .catch( error => {
            console.error( error );
        } );

    ClassicEditor
        .create( document.querySelector( '#bodyForum' ) )
        .catch( error => {
            console.error( error );
        } );

    var replies = <?php echo json_encode($forum->replies->toArray()); ?>;
    replies.forEach(function(item) {
        ClassicEditor
            .create(document.querySelector('#bodyEditReply-' + item.id))
            .catch(error => {
                console.error(error);
        });
    });

    $('#createReply').modal( {
        focus: false
    });
    $('#editReply').modal( {
        focus: false
    });
    $('#editThread').modal( {
        focus: false
    });
</script>
<?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/forum/show.blade.php ENDPATH**/ ?>