<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Attendance - '.e($classSubject->name).' '.e($classSubject->className).'']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Attendance - '.e($classSubject->name).' '.e($classSubject->className).'']); ?>

     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <div id="content" class="container my-5 py-5">
        <div class="mb-3">
            <span class="fa-stack fa-md ms-n1">
                <i class="fas fa-circle fa-stack-2x text-orange"></i>
                <a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left fa-stack-1x fa-inverse text-light" style="text-decoration: none;"></a>
            </span>
        </div>
        <div class="">
            <div class="">
                <h3>Attendance - Subject <?php echo e($classSubject->name); ?></h3>
                <h5><?php echo e($classSubject->className); ?> - <?php echo e($classSubject->schoolYear); ?> <?php echo e($classSubject->semester); ?></h5>
                <hr>
                <form action="<?php echo e(route('attendance.create')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="my-3">
                        <label for="class_name" class="form-label">Date</label>
                        <input type="text" value="<?php echo e(date_format(date_create(date('y-m-d')),"d F Y")); ?>"
                            class="form-control" name="date_today" readonly>
                    </div>
                    <hr>
                    <div class="my-3">
                        <input type="checkbox" onClick="presentAll(this)" class="presentAll mb-3"> Present all
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead class="table-dark">
                                    <th class="align-middle text-center">No</th>
                                    <th class="align-middle text-center">NISN</th>
                                    <th class="align-middle text-center">Student Name</th>
                                    <th class="align-middle text-center">Present</th>
                                    <th class="align-middle text-center">Sick</th>
                                    <th class="align-middle text-center">Absence Permit</th>
                                    <th class="align-middle text-center">Absent</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $class_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle text-center"><?php echo e($index+1); ?></td>
                                        <td class="align-middle text-center"><?php echo e($student->studentNisn); ?></td>
                                        <td class="align-middle text-center"><?php echo e($student->studentName); ?></td>
                                        <td class="align-middle text-center">
                                            <input type="checkbox" value="1" class="form-check-input attend radio"
                                                name="present-<?php echo e($student->studentId); ?>">
                                        </td>
                                        <td class="align-middle text-center">
                                            <input type="checkbox" value="1" class="form-check-input radio"
                                                name="sick-<?php echo e($student->studentId); ?>">
                                        </td>
                                        <td class="align-middle text-center">
                                            <input type="checkbox" value="1" class="form-check-input radio"
                                                name="absencePermit-<?php echo e($student->studentId); ?>">
                                        </td>
                                        <td class="align-middle text-center">
                                            <input type="checkbox" value="1" class="form-check-input radio"
                                                name="absent-<?php echo e($student->studentId); ?>">
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <input type="hidden" name="class_subject_id" value="<?php echo e($classSubject->id); ?>">
                    <button type="submit" class="btn btn-primary text-white">Submit</button>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<script>
    function presentAll(source) {
        //uncheck all checkbox
        allCheckbox = document.getElementsByClassName('form-check-input');
        for (var i = 0, n = allCheckbox.length; i < n; i++) {
            allCheckbox[i].checked = source.unchecked;
        }

        checkboxes = document.getElementsByClassName('attend');
        for (var i = 0, n = checkboxes.length; i < n; i++) {
            checkboxes[i].checked = source.checked;
        }
    }

    $("input:checkbox").on('click', function() {
        var box = $(this);
        if (box.is(":checked")) {
            if(box.attr('class') != 'presentAll mb-3'){
                var studentId = box.attr("name").split('-')[1];
            }

            var groupPresent = "input:checkbox[name=present-" + studentId + "]";
            var groupSick = "input:checkbox[name=sick-" + studentId + "]";
            var groupAbsencePermit = "input:checkbox[name=absencePermit-" + studentId + "]";
            var groupAbsent = "input:checkbox[name=absent-" + studentId + "]";
            
            $(groupPresent).prop("checked", false);
            $(groupSick).prop("checked", false);
            $(groupAbsencePermit).prop("checked", false);
            $(groupAbsent).prop("checked", false);
            box.prop("checked", true);
        }else{
            box.prop("checked", false);
        }
    });
</script>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="script.js"></script><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/attendance/create.blade.php ENDPATH**/ ?>