<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Student List - '.e($class->name).' '.e($schoolYear->year).' - '.e($schoolYear->semester).'']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Student List - '.e($class->name).' '.e($schoolYear->year).' - '.e($schoolYear->semester).'']); ?>
      <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

     <div id="content" class="container py-5 my-5">
          <h3 class="fw-bold">Student List - <?php echo e($class->name); ?> <?php echo e($schoolYear->year); ?> - <?php echo e($schoolYear->semester); ?></h3>
          <a type="button" class="btn btn-dark text-white mb-3" href="<?php echo e(route('admin-class-view', $schoolYear->id)); ?>">
               Back
          </a>
          <button type="button" class="btn btn-primary text-white mb-3" data-bs-toggle="modal"
          data-bs-target="#addStudent">
          Assign Student to Class
          </button>
          <div class="table-responsive">
               <table class="table table-hover table-bordered">
                   <thead class="table-light">
                         <th class="align-middle text-center">No</th>
                         <th class="align-middle text-center">NISN</th>
                         <th class="align-middle text-center">Student Name</th>
                         <th class="align-middle text-center">Action</th>
                    </thead>
                    <tbody>
                         <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                   <td class="align-middle text-center"><?php echo e($index+1); ?></td>
                                   <td class="align-middle text-center"><?php echo e($student->nisn); ?></td>
                                   <td class="align-middle text-center"><?php echo e($student->name); ?></td>
                                   <td class="align-middle text-center">
                                        <button type="button" class="btn btn-danger text-white justify-content-between"
                                             data-bs-toggle="modal"
                                             data-bs-target="#delete-<?php echo e($student->classDetailId); ?>">
                                             Remove
                                        </button>
                                   </td>
                              </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
               </table>
          </div>
     </div>

     <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="modal fade show pr-0" style="z-index: 9999;" id="delete-<?php echo e($student->classDetailId); ?>"
          tabindex="-1" role="dialog" aria-labelledby="alertTitle" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content rounded-20 border-0">
                         <div class="modal-header border-bottom-0">
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                         </div>
                         <div class="modal-body">
                              <div class="row d-flex justify-content-center align-items-center">
                                   <div class="col-12 mb-3 text-center">
                                   <span class="fa-stack fa-4x">
                                        <i class="fas fa-circle fa-stack-2x text-danger"></i>
                                        <i class="fas fa-exclamation-triangle fa-stack-1x fa-inverse"></i>
                                   </span>
                                   </div>
                                   <div class="col-12 my-2 text-center">
                                   <h4 class="font-weight-bold">Are you sure want to remove this data?</h4>

                                   <div class="d-flex justify-content-center">
                                        <button type="button" class="btn btn-light text-dark justify-content-between mx-2"
                                             data-bs-dismiss="modal">
                                             Cancel
                                        </button>
                                        <form action="<?php echo e(route('admin-class-remove-student', $student->classDetailId)); ?>"
                                             method="POST">
                                             <?php echo csrf_field(); ?>
                                             <?php echo method_field('delete'); ?>
                                             <button type="submit" class="btn btn-danger text-white justify-content-between">
                                                  Yes, remove it
                                             </button>
                                        </form>
                                   </div>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     <div class="modal fade" id="addStudent" tabindex="-1" aria-labelledby="addStudent"
     aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg">
              <div class="modal-content">
                  <div class="modal-header">
                      <h5 class="modal-title" id="submitLabel">Assign Student to Class</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('admin-class-assign-student',$class->id)); ?>">
                         <?php echo csrf_field(); ?>
                         <div class="">
                              <label for="school_year" class="form-label">School Year</label>
                              <input type="text" class="form-control" name="school_year" value="<?php echo e($schoolYear->year); ?> - <?php echo e($schoolYear->semester); ?>" readonly>
                         </div>
                         <div class="my-3">
                              <label for="class_name" class="form-label">Class</label>
                              <input type="text" class="form-control" name="class_name" value="<?php echo e($class->name); ?>"  readonly>
                         </div>
                         <div class="my-3">
                              <label for="student_id" class="form-label">Student <span class="required">*</span></label>
                              <select name="student_id" class="form-select" required>
                                   <option value="" selected>--Please Choose--</option>
                                   <?php $__currentLoopData = $studentsNotAssigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($student->id); ?>"><?php echo e($student->nisn); ?> - <?php echo e($student->name); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                         </div>
                         <div class="d-grid">
                              <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                          </div>
                    </form>
                  </div>
              </div>
          </div>
     </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/admin/class-student-list.blade.php ENDPATH**/ ?>