<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Students - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Students - Learningku']); ?>
    <style>
        .fa-stack.small { font-size: 0.5em; }
        i { vertical-align: middle; }
    </style>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <section id="headerClassSubject">
        <div id="content" class="container pt-5 mt-5">
            <section id="headerClassDetail">
 
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-10">
                                <h2 class="fw-bold">Subject <?php echo e($classSubject->name); ?></h2>
                                <h5 class="pb-2">Teacher: <?php echo e($classSubject->teacherName); ?> - <?php echo e($classSubject->teacherNuptk); ?></h5>
                                <h5><span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-home fa-stack-1x fa-2xs fa-inverse text-white"></i></span> <?php echo e($classSubject->className); ?> - <?php echo e($classSubject->schoolYear); ?> <?php echo e($classSubject->semester); ?> <span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-user fa-stack-1x fa-2xs fa-inverse text-white"></i></span> Homeroom Teacher: <?php echo e($classSubject->homeRoomTeacherName); ?> - <?php echo e($classSubject->homeRoomTeacherNuptk); ?></h5>
                            </div>           
                        </div>
                    </div>
                </div>
            </section>
    
            <nav class="" style="font-size:1.25rem">
                
                    <ul class="nav nav-tabs">
                        <?php if(auth()->user()->role->name == 'Teacher'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('class-view-student', $classSubject->id )); ?>">Students</a></li>
                        <?php endif; ?>
        
                        <?php if(auth()->user()->role->name == 'Student'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forum Discussions</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                        <?php endif; ?>
                    </ul>
                
            </nav>
        </div>
    </section>
 
     <div id="content" class="container my-3">
          <div class="table-responsive pt-2">
               <table class="table table-hover table-bordered">
                    <thead class="table-dark">
                         <th class="align-middle text-center">No</th>
                         <th class="align-middle text-center">NISN</th>
                         <th class="align-middle text-center">Student Name</th>
                    </thead>
                    <tbody>
                         <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                   <td class="align-middle text-center"><?php echo e($index+1); ?></td>
                                   <td class="align-middle text-center"><?php echo e($student->nisn); ?></td>
                                   <td class="align-middle text-center"><?php echo e($student->name); ?></td>
                              </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
               </table>
          </div>
     </div>
  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/class/student-list.blade.php ENDPATH**/ ?>