<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Dashboard - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Dashboard - Learningku']); ?>

    <div id="content" class="container pt-5 mt-5">
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-body m-3">
                <div class="row align-items-center">
                    <div class="col-md-2">
                        <img src="/storage/assets/man.svg" width="100%" alt="" class="rounded-circle bg-color-lightblue">
                    </div>
                    <div class="col-md-10">
                        <h1 class="fw-bold">Welcome, <?php echo e(auth()->user()->name); ?></h1>
                        <p><?php echo e(auth()->user()->role->name); ?></p>
                        <hr>
                    </div>           
                </div>
            </div>
        </div>
    </div>


    <?php if(auth()->user()->role == 'Admin'): ?>
        <?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(auth()->user()->role == 'Teacher'): ?>
        <?php echo $__env->make('dashboard.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(auth()->user()->role == 'Student'): ?>
        <?php echo $__env->make('dashboard.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/dashboard/index.blade.php ENDPATH**/ ?>