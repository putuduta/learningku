<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Score Update - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Score Update - Learningku']); ?>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <div id="content" class="container py-5 my-5">
        <h3 class="fw-bold">Update Score</h3>
        <hr>
        <a href="<?php echo e(URL::to('/')); ?>/score/detail/<?php echo e($class); ?>/<?php echo e($score->student_user_id); ?>" class="btn btn-primary text-white mb-3">Back to Student Score</a>

        <form action="<?php echo e(route('score.update', $score->id)); ?>" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="my-3">
                <label for="score_name" class="form-label">Assignment Name</label>
                <input type="text" class="form-control" name="score_name" id="score_name" required
                    value="<?php echo e($score->assignment_header->title); ?>" readonly>
            </div>
            <div class="my-3">
                <label for="score" class="form-label">Score</label>
                <input type="number" class="form-control" name="score" id="score" required
                    value="<?php echo e($score->score); ?>">
            </div>
            <div class="d-grid">
                <?php echo method_field('put'); ?>
                <button type="submit" class="btn btn-primary my-4 text-white">Update</button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/score/change.blade.php ENDPATH**/ ?>