<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Assignments - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Assignments - Learningku']); ?>
    <style>
        .fa-stack.small { font-size: 0.5em; }
        i { vertical-align: middle; }
    </style>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <section id="headerClassSubject">
        <div id="content" class="container pt-5 mt-5">
            <section id="headerClassDetail">
    
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-10">
                                <h2 class="fw-bold">Subject <?php echo e($classSubject->name); ?></h2>
                                <h5 class="pb-2">Teacher: <?php echo e($classSubject->teacherName); ?> - <?php echo e($classSubject->teacherNuptk); ?></h5>
                                <h5><span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-home fa-stack-1x fa-2xs fa-inverse text-white"></i></span> <?php echo e($classSubject->className); ?> - <?php echo e($classSubject->schoolYear); ?> <?php echo e($classSubject->semester); ?> <span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-user fa-stack-1x fa-2xs fa-inverse text-white"></i></span> Homeroom Teacher: <?php echo e($classSubject->homeRoomTeacherName); ?> - <?php echo e($classSubject->homeRoomTeacherNuptk); ?></h5>
                            </div>           
                        </div>
                    </div>
                </div>
            </section>
    
            <nav class="" style="font-size:1.25rem">
                
                    <ul class="nav nav-tabs">
                        <?php if(auth()->user()->role->name == 'Teacher'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('class-view-student', $classSubject->id )); ?>">Students</a></li>
                        <?php endif; ?>
        
                        <?php if(auth()->user()->role->name == 'Student'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                        <?php endif; ?>
                    </ul>
                
            </nav>
        </div>
    </section>

    <div id="content" class="container my-3">
        <?php if(auth()->user()->role->name == 'Teacher'): ?>
        <div class="text-end">
            <button type="button" class="btn btn-primary text-white mb-3" data-bs-toggle="modal"
                data-bs-target="#newAssignment">
                Create New Assignment
            </button>
        </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">No</th>
                    <th class="align-middle text-center">Title</th>
                    <th class="align-middle text-center">Deadline</th>
                    <?php if(auth()->user()->role->name == 'Student'): ?>
                        <th class="align-middle text-center">Status</th>
                    <?php endif; ?>
                    <th class="align-middle text-center">Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="align-middle text-center"><?php echo e($index + 1); ?></td>
                            <td class="align-middle text-center"><?php echo e($assignment->title); ?></td>
                            <td class="align-middle text-center">
                                <?php echo e(date_format(date_create($assignment->end_time), 'd F Y H:i')); ?>

                            </td>
                            <?php if(auth()->user()->role->name == 'Student'): ?>
                                <?php if(count($assignment->submissionUser) > 0): ?>
                                    <td class="align-middle text-center bg-success text-white">Submitted</td>
                                <?php else: ?>
                                    <td class="align-middle text-center bg-danger text-white">Not Submitted</td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <td class="align-middle text-center">
                                <a href="/storage/assignment/<?php echo e($assignment->file); ?>" download
                                    class="btn btn-success text-white">
                                    Download Assignment
                                </a>
                                <?php if(auth()->user()->role->name == 'Student'): ?>
                                    <?php if(strtotime($assignment->end_time) > time()): ?>
                                        <button type="button" class="btn btn-primary text-white" data-bs-toggle="modal"
                                            data-bs-target="#submit-<?php echo e($assignment->id); ?>">
                                            Submit
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-primary text-white" data-bs-toggle="modal"
                                            data-bs-target="#submit-<?php echo e($assignment->id); ?>" disabled>
                                            Submit
                                        </button>
                                    <?php endif; ?>
                                    <button type="button" class="btn btn-dark text-white" data-bs-toggle="modal"
                                        data-bs-target="#history-<?php echo e($assignment->id); ?>">
                                        Submission History
                                    </button>
                                <?php elseif(auth()->user()->role->name == 'Teacher'): ?>
                                    <?php if(!(strtotime($assignment->end_time) > time())): ?>
                                    <a href="<?php echo e(route('assignment.showDetails', ['assignmentId' => $assignment->id, 'classSubjectId' => $classSubject->id])); ?>"
                                        class="btn btn-primary text-white">
                                        Show Submissions
                                    </a>
                                    <button type="button" class="btn btn-primary text-white justify-content-between" data-bs-toggle="modal"
                                    data-bs-target="#updateAssignment<?php echo e($assignment->id); ?>" disabled>
                                        Update
                                    </button>
                                    <?php else: ?> 
                                    <button type="button" class="btn btn-primary text-white justify-content-between" disabled>
                                        Show Submissions
                                    </button>
                                    <button type="button" class="btn btn-primary text-white justify-content-between" data-bs-toggle="modal"
                                    data-bs-target="#updateAssignment<?php echo e($assignment->id); ?>">
                                        Update
                                    </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<!-- Modal -->
<?php if(auth()->user()->role->name == 'Teacher'): ?>
    <div class="modal fade" id="newAssignment" tabindex="-1" aria-labelledby="newAssignmentLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newAssignmentLabel">Create New Assignment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('assignment.add', $classSubject->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="my-3">
                            <label for="title" class="form-label">Title <span class="required">*</span></label>
                            <input type="text" class="form-control" name="title" id="title" required>
                        </div>
                        <div class="my-3">
                            <label for="body" class="form-label">Deadline <span class="required">*</span></label>
                            <input type="datetime-local" class="form-control" name="end_time" id="end_time" min="<?=date('Y-m-d\Th:i')?>" required>
                        </div>
                        <div class="my-3">
                            <label for="file" class="form-label">Assignment File <span class="required">*</span></label>
                            <input class="form-control" name="file" type="file" id="file" required>
                        </div>
                        <div class="d-grid">
                            <input type="hidden" name="class_subject_id" value="<?php echo e($classSubject->id); ?>">
                            <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="updateAssignment<?php echo e($assignment->id); ?>" tabindex="-1" aria-labelledby="updateAssignmentLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateAssignmentLabel">Update Assignment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('assignment.update', $assignment->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="my-3">
                            <label for="title" class="form-label">Title <span class="required">*</span></label>
                            <input type="text" class="form-control" name="title" value="<?php echo e($assignment->title); ?>" id="title" required>
                        </div>
                        <div class="my-3">
                            <label for="body" class="form-label">Deadline <span class="required">*</span></label>
                            <input type="datetime-local" class="form-control" name="end_time" value="<?php echo e($assignment->end_time); ?>" id="end_time" min="<?=date('Y-m-d\Th:i')?>" required>
                        </div>
                        <div class="my-3">
                            <label for="file" class="form-label">Assignment File</label>
                            <input class="form-control" name="file" type="file" id="file">
                            <input class="form-control" name="assignment_file" type="text" id="assignment_file" value="<?php echo e($assignment->file); ?>" hidden>
                        </div>
                        <div class="d-grid">
                            <input type="hidden" name="class_subject_id" value="<?php echo e($classSubject->id); ?>">
                            <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(auth()->user()->role->name == 'Student'): ?>
    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="submit-<?php echo e($assignment->id); ?>" tabindex="-1" aria-labelledby="submitLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="submitLabel">Submit Assignment - <?php echo e($assignment->title); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('assignment.submit', $assignment)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="my-3">
                                <label for="file" class="form-label">Submission File</label>
                                <input class="form-control" name="file" type="file" id="file">
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="history-<?php echo e($assignment->id); ?>" tabindex="-1" aria-labelledby="historyLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="historyLabel">Assignment Submission History - <?php echo e($assignment->title); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <?php if(count($assignment->submissionUser) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <thead class="table-dark">
                                        <th class="align-middle text-center">No</th>
                                        <th class="align-middle text-center">File Name</th>
                                        <th class="align-middle text-center">Submission Time</th>
                                        <th class="align-middle text-center">Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $assignment->submissionUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="align-middle text-center"><?php echo e($index + 1); ?></td>
                                                <td class="align-middle text-center"><?php echo e($submission->file); ?></td>
                                                <td class="align-middle text-center">
                                                    <?php echo e(date_format(date_create($submission->created_at), 'd F Y H:i')); ?>

                                                </td>
                                                <td class="align-middle text-center">
                                                    <a href="/storage/assignment/submission/<?php echo e($submission->file); ?>" download
                                                        class="btn btn-success text-white">
                                                        Download
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <h5 class="text-center">No Data</h5>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<script>
    function checkEndTime(id) {
        if (id == 1) {
            alert("The deadline is not over yet!");
            return false;
        } else {
            return true;
        }
    }
</script><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/assignment/index.blade.php ENDPATH**/ ?>