<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Score Detail - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Score Detail - Learningku']); ?>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <div id="content" class="container py-5 my-5">
        <h3 class="fw-bold"><?php echo e($student->name); ?>'s score</h3>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">No</th>
                    <th class="align-middle text-center">Assignment Name</th>
                    <th class="align-middle text-center">Score</th>
                    <th class="align-middle text-center">Action</th>
                </thead>
                <tbody>
                    <div>
                        <a href="<?php echo e(route('score.index', $class)); ?>" class="btn btn-primary text-white mb-3">Back to Student List</a>
                    </div>
                    <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($s->score != null): ?>
                        <tr>
                            <td class="align-middle text-center"><?php echo e($index + 1); ?></td>
                            <td class="align-middle text-center"><?php echo e($s->assignment_header->title); ?></td>
                            <td class="align-middle text-center"><?php echo e($s->score); ?></td>
                            <td class="align-middle text-center">
                                <a href="<?php echo e(URL::to('/')); ?>/score/edit/<?php echo e($class); ?>/<?php echo e($s->id); ?>"
                                    class="btn btn-primary text-white">
                                    Edit Score
                                </a>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/score/show.blade.php ENDPATH**/ ?>