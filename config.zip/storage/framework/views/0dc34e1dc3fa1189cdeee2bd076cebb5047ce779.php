<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Assignment Detail - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Assignment Detail - Learningku']); ?>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <div id="content" class="container py-5 my-5">
        <div class="mb-3">
            <span class="fa-stack fa-md ms-n1">
                <i class="fas fa-circle fa-stack-2x text-orange"></i>
                <a href="<?php echo e(route('assignment.index', $classSubject->id)); ?>" class="fas fa-arrow-left fa-stack-1x fa-inverse text-light" style="text-decoration: none;"></a>
            </span>
        </div>
        <h3 class="fw-bold">Assignment Submissions - <?php echo e($assignmentHeader->title); ?> - (<?php echo e($classSubject->name); ?> - <?php echo e($classSubject->className); ?>)</h3>
        <hr>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">No</th>
                    <th class="align-middle text-center">NISN</th>
                    <th class="align-middle text-center">Student Name</th>
                    <th class="align-middle text-center">Submission Time</th>
                    <th class="align-middle text-center">Score</th>
                    <th class="align-middle text-center">Action</th>
                </thead>
                <tbody>
                    <?php ($i = 1); ?>
                    <?php $__currentLoopData = $assignmentScore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($tempStudentId = null); ?>
                        <?php ($tempAsgCreatedAt = null); ?>
                        <?php if($assignments->count() > 0): ?>
                            <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($score->assignmentHeaderId == $assignment->assignmentId && $score->studentUserId == $assignment->studentUserId): ?>
                                    <?php if($score->score == 0 && $assignment->file === null): ?>                                  
                                    <tr>
                                        <td class="align-middle text-center"><?php echo e($i); ?></td>
                                        <td class="align-middle text-center"><?php echo e($score->nisn); ?></td>
                                        <td class="align-middle text-center"><?php echo e($score->studentName); ?></td>
                                        <td class="align-middle text-center bg-danger text-white">
                                        Not Submitted
                                        </td>
                                        <td class="align-middle text-center">
                                            <?php echo e($score->score); ?>

                                        </td>
                                        <td class="align-middle text-center">
                                            -
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    
                                    <tr>
                                        <td class="align-middle text-center"><?php echo e($i); ?></td>
                                        <td class="align-middle text-center"><?php echo e($score->nisn); ?></td>
                                        <td class="align-middle text-center"><?php echo e($assignment->studentName); ?></td>
                                        <td class="align-middle text-center bg-success text-white">
                                            <?php echo e(date_format(date_create($assignment->createdAt),"d F Y H:i")); ?>

                                        </td>
                                        <td class="align-middle text-center">
                                            <?php if($score->score == null): ?>
                                                -
                                            <?php else: ?>
                                                <?php echo e($score->score); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td class="align-middle text-center">
                                            <a href="/storage/assignment/submission/<?php echo e($assignment->file); ?>" download
                                                class="btn btn-success text-white">
                                                Download Submission
                                            </a>
                                            <?php if($score->score == null): ?>
                                                <button type="button" class="btn btn-primary text-white" data-bs-toggle="modal"
                                                    data-bs-target="#newScore<?php echo e($assignment->assignmentId); ?><?php echo e($assignment->studentUserId); ?>">
                                                    Give Score
                                                </button>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-primary text-white" data-bs-toggle="modal"
                                                    data-bs-target="#updateScore<?php echo e($assignment->assignmentId); ?><?php echo e($assignment->studentUserId); ?>">
                                                    Edit Score
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    
                                    <?php endif; ?>
                                    <?php ($tempStudentId = $assignment->studentUserId); ?>
                                    <?php ($tempAsgCreatedAt = $assignment->createdAt); ?>
                                <?php else: ?> 
                                    <?php if($score->score === 0): ?>
                                    <tr>
                                        <td class="align-middle text-center"><?php echo e($i); ?></td>
                                        <td class="align-middle text-center"><?php echo e($score->nisn); ?></td>
                                        <td class="align-middle text-center"><?php echo e($score->studentName); ?></td>
                                        <td class="align-middle text-center bg-danger text-white">
                                        Not Submitted
                                        </td>
                                        <td class="align-middle text-center">
                                            <?php echo e($score->score); ?>

                                        </td>
                                        <td class="align-middle text-center">
                                            -
                                        </td>
                                    </tr> 
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    <?php ($i++); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php $__currentLoopData = $assignmentScore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="newScore<?php echo e($score->assignmentHeaderId); ?><?php echo e($score->studentUserId); ?>" tabindex="-1" aria-labelledby="newScoreLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newAssignmentLabel">Give Score (<?php echo e($score->nisn); ?> - <?php echo e($score->studentName); ?>)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('score.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="">
                        <label for="score" class="form-label">Score <span class="required">*</span></label>
                        <input type="number" class="form-control" name="score" id="score" min="0" max="100" required>
                    </div>
                    <div class="pt-2">
                        <label for="score" class="form-label">Notes/Feedback (Optional)</label>
                        <textarea name="notes" id="bodyNewScore<?php echo e($score->assignmentHeaderId); ?><?php echo e($score->studentUserId); ?>" cols="20" rows="10" class="form-control"
                        ></textarea>
                    </div>
                    <div class="d-grid">
                        <input type="hidden" name="score_id" value="<?php echo e($score->id); ?>">
                        <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $assignmentScore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="updateScore<?php echo e($score->assignmentHeaderId); ?><?php echo e($score->studentUserId); ?>" tabindex="-1" aria-labelledby="newScoreLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newAssignmentLabel">Edit Score (<?php echo e($score->nisn); ?> - <?php echo e($score->studentName); ?>)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('score.update', $score->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="">
                        <label for="score" class="form-label">Score <span class="required">*</span></label>
                        <input type="number" class="form-control" name="score" id="score" min="0" max="100" value="<?php echo e($score->score); ?>" required>
                    </div>
                    <div class="">
                        <label for="score" class="form-label">Notes/Feedback (Optional)</label>
                        <textarea name="notes" id="bodyUpdateScore<?php echo e($score->assignmentHeaderId); ?><?php echo e($score->studentUserId); ?>" cols="30" rows="10" class="form-control"
                        ><?php echo e($score->notes); ?></textarea>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary my-4 text-white">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<script>
    var scores = <?php echo json_encode($assignmentScore->toArray()); ?>;
    scores.forEach(function(item) {
        console.log('#bodyNewScore' + item.assignmentHeaderId + item.studentUserId)
        ClassicEditor
            .create(document.querySelector('#bodyNewScore' + item.assignmentHeaderId + item.studentUserId))
            .catch(error => {
                console.error(error);
        });

        ClassicEditor
            .create(document.querySelector('#bodyUpdateScore' + item.assignmentHeaderId + item.studentUserId))
            .catch(error => {
                console.error(error);
        });
    });

    $('.modal').modal( {
        focus: false
    });
    
</script><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/assignment/show.blade.php ENDPATH**/ ?>