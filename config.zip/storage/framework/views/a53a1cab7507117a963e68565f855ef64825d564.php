<?php if(auth()->user()->role->name == 'Student'): ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Scores - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Scores - Learningku']); ?>
    <style>
        .fa-stack.small { font-size: 0.5em; }
        i { vertical-align: middle; }
    </style>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <section id="headerClassSubject">
        <div id="content" class="container pt-5 mt-5">
            <section id="headerClassDetail">
    
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-10">
                                <h2 class="fw-bold">Subject <?php echo e($classSubject->name); ?></h2>
                                <h5 class="pb-2">Teacher: <?php echo e($classSubject->teacherName); ?> - <?php echo e($classSubject->teacherNuptk); ?></h5>
                                <h5><span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-home fa-stack-1x fa-2xs fa-inverse text-white"></i></span> <?php echo e($classSubject->className); ?> - <?php echo e($classSubject->schoolYear); ?> <?php echo e($classSubject->semester); ?> <span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-user fa-stack-1x fa-2xs fa-inverse text-white"></i></span> Homeroom Teacher: <?php echo e($classSubject->homeRoomTeacherName); ?> - <?php echo e($classSubject->homeRoomTeacherNuptk); ?></h5>
                            </div>           
                        </div>
                    </div>
                </div>
            </section>
            <nav class="" style="font-size:1.25rem">
                
                    <ul class="nav nav-tabs">
                        <?php if(auth()->user()->role->name == 'Teacher'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('class-view-student', $classSubject->id )); ?>">Students</a></li>
                        <?php endif; ?>
        
                        <?php if(auth()->user()->role->name == 'Student'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                        <?php endif; ?>
                    </ul>
                
            </nav>
        </div>
    </section>
    <div id="content" class="container my-3">
        
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">No</th>
                    <th class="align-middle text-center">Assignment Name</th>
                    <th class="align-middle text-center">Score</th>
                    <th class="align-middle text-center">Notes/Feedback</th>
                </thead>
                <tbody>
                    <?php $score = 0; $count = 0; ?>
                    <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!(strtotime($s->assignment_header->end_time) > time()) && $s->score != null): ?>
                        <tr>
                            <td class="align-middle text-center"><?php echo e($index + 1); ?></td>
                            <td class="align-middle text-center"><?php echo e($s->assignment_header->title); ?></td>
                            <td class="align-middle text-center"><?php echo e($s->score); ?></td>
                            <td class="align-middle text-center">
                                <button type="button" class="btn btn-primary text-white justify-content-between" data-bs-toggle="modal"
                                data-bs-target="#notes<?php echo e($s->id); ?>">
                                    Show
                                </button>
                            </td>
                        </tr>
                        <?php $score += $s->score; $count += 1; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="table-responsive-sm">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">Overall Score</th>
                    <th class="align-middle text-center">Minimum Score</th>
                </thead>
                <tbody>
                    <?php if( $score/$count > $classSubject->minimum_score): ?>
                    <td class="align-middle text-center bg-success">  
                    <?php else: ?>
                    <td class="align-middle text-center bg-danger">
                    <?php endif; ?>
                        <?php echo e(round($score/$count)); ?></td>
                    <td class="align-middle text-center">
                        <?php echo e($classSubject->minimum_score); ?></td></td>                         
                </tbody>
            </table>
        </div>
    </div>

    <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(!(strtotime($s->assignment_header->end_time) > time())): ?>
    <div class="modal fade" id="notes<?php echo e($score->id); ?>" tabindex="-1" aria-labelledby="notesModal"
        aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <?php if($score->notes == null): ?> 
                    <h5>No Notes/Feedback</h5>
                    <?php else: ?>
                    <?php echo $score->notes; ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php else: ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => ['title' => 'Scores - Learningku']]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Scores - Learningku']); ?>
    <style>
        .fa-stack.small { font-size: 0.5em; }
        i { vertical-align: middle; }
    </style>
     <?php $__env->slot('navbar', null, []); ?>  <?php $__env->endSlot(); ?>

    <section id="headerClassSubject">
        <div id="content" class="container pt-5 mt-5">
            <section id="headerClassDetail">
    
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-10">
                                <h2 class="fw-bold">Subject <?php echo e($classSubject->name); ?></h2>
                                <h5 class="pb-2">Teacher: <?php echo e($classSubject->teacherName); ?> - <?php echo e($classSubject->teacherNuptk); ?></h5>
                                <h5><span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-home fa-stack-1x fa-2xs fa-inverse text-white"></i></span> <?php echo e($classSubject->className); ?> - <?php echo e($classSubject->schoolYear); ?> <?php echo e($classSubject->semester); ?> <span class="fa-stack small pb-4"><i class="fas fa-circle fa-stack-2x text-orange"></i><i class="fas fa-user fa-stack-1x fa-2xs fa-inverse text-white"></i></span> Homeroom Teacher: <?php echo e($classSubject->homeRoomTeacherName); ?> - <?php echo e($classSubject->homeRoomTeacherNuptk); ?></h5>
                            </div>           
                        </div>
                    </div>
                </div>
            </section>
    
            <nav class="" style="font-size:1.25rem">
                
                    <ul class="nav nav-tabs">
                        <?php if(auth()->user()->role->name == 'Teacher'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('class-view-student', $classSubject->id )); ?>">Students</a></li>
                        <?php endif; ?>
        
                        <?php if(auth()->user()->role->name == 'Student'): ?>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('material.index', $classSubject->id)); ?>">Materials</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('forum.index', $classSubject->id )); ?>">Forums</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('assignment.index', $classSubject->id )); ?>">Assignments</a></li>
                            <li class="nav-item"><a class="nav-link active" style="color: black" href="<?php echo e(route('score.index', $classSubject->id )); ?>">Scores</a></li>
                            <li class="nav-item"><a class="nav-link" style="color: black" href="<?php echo e(route('attendance.view', $classSubject->id )); ?>">Attendances</a></li>
                        <?php endif; ?>
                    </ul>
                
            </nav>
        </div>
    </section>

    <div id="content" class="container my-3">
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead class="table-dark">
                    <th class="align-middle text-center">No</th>
                    <th class="align-middle text-center">NISN</th>
                    <th class="align-middle text-center">Student Name</th>
                    <th class="align-middle text-center">Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $class_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle text-center"><?php echo e($index+1); ?></td>
                                    <td class="align-middle text-center"><?php echo e($student->studentNisn); ?></td>
                                    <td class="align-middle text-center"><?php echo e($student->studentName); ?></td>
                                    <td class="align-middle text-center">
                                        <button type="button" class="btn btn-primary text-white" data-bs-toggle="modal"
                                        data-bs-target="#detail-<?php echo e($student->studentId); ?>">
                                            Show Scores
                                        </button>
                                    </td>
                                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php $__currentLoopData = $class_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="detail-<?php echo e($student->studentId); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Scores -  (<?php echo e($student->studentName); ?> - <?php echo e($student->studentNisn); ?>)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead class="table-dark">
                            <th class="align-middle text-center">No</th>
                            <th class="align-middle text-center">Assignment Name</th>
                            <th class="align-middle text-center">Score</th>
                        </thead>
                        <tbody>
                            <?php $score = 0; $count = 0; ?>
                            <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($s->student_user_id == $student->studentId): ?>
                                    <?php if(!(strtotime($s->assignment_header->end_time) > time()) && $s->score !== null): ?>
                                    <?php $score += $s->score; $count += 1; ?>
                                    <tr>
                                        <td class="align-middle text-center"><?php echo e($count); ?></td>
                                        <td class="align-middle text-center"><?php echo e($s->assignment_header->title); ?></td>
                                        <td class="align-middle text-center"><?php echo e($s->score); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive-sm">
                    <table class="table table-hover table-bordered">
                        <thead class="table-dark">
                            <th class="align-middle text-center">Overall Score</th>
                            <th class="align-middle text-center">Minimum Score</th>
                        </thead>
                        <tbody>
                            <?php if( $score/$count > $classSubject->minimum_score): ?>
                            <td class="align-middle text-center bg-success">  
                            <?php else: ?>
                            <td class="align-middle text-center bg-danger">
                            <?php endif; ?>
                                <?php echo e(round($score/$count)); ?></td>
                            <td class="align-middle text-center">
                                <?php echo e($classSubject->minimum_score); ?></td></td>                         
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary text-white" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp-new\htdocs\New folder\learningku\resources\views/score/index.blade.php ENDPATH**/ ?>