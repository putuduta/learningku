<x-master title="{{ $title }}">
    <x-slot name="navbarUser"></x-slot>
    <x-slot name="sidebar"></x-slot>
    {{ $slot }}
</x-master>
